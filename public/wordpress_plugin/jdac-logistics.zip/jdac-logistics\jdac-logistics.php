<?php
/**
 * Plugin Name: Jdac Logistics
 * Plugin URI:  https://ship.jdaclogistics.com/
 * Description: Connect your WooCommerce store with Jdac Logistics. Sync orders automatically and manage your shipments directly from the Jdac Logistics portal.
 * Version:     1.1.0
 * Author:      Softieons
 * Text Domain: jdac-logistics
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Prevent direct access
}

/**
 * Check if WooCommerce is active
 */
function jdac_logistics_check_woocommerce() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', 'jdac_logistics_missing_woocommerce_notice' );
        return false;
    }
    return true;
}

/**
 * Display notice if WooCommerce is missing
 */
function jdac_logistics_missing_woocommerce_notice() {
    ?>
    <div class="error">
        <p><?php _e( 'Jdac Logistics requires WooCommerce to be installed and active. Please install WooCommerce to use this plugin.', 'jdac-logistics' ); ?></p>
    </div>
    <?php
}

// Check for WC
if ( ! class_exists( 'WooCommerce' ) ) {
    add_action( 'admin_notices', 'jdac_logistics_missing_woocommerce_notice' );
} else {

class Jdac_Logistics_Plugin {

    public function __construct() {
        // Admin Menu
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );

        // Register Settings
        add_action( 'admin_init', array( $this, 'register_settings' ) );

        // Order Sync Hooks (Processing, Completed, and Changed)
        add_action( 'woocommerce_order_status_processing', array( $this, 'send_order_to_jdac' ), 10, 1 );
        add_action( 'woocommerce_order_status_completed', array( $this, 'send_order_to_jdac' ), 10, 1 );
        add_action( 'woocommerce_order_status_cancelled', array( $this, 'send_order_to_jdac' ), 10, 1 );
        add_action( 'woocommerce_order_status_changed', array( $this, 'handle_status_change' ), 10, 4 );

        // REST API
        add_action( 'rest_api_init', array( $this, 'register_api_endpoints' ) );

        // Add custom styles for the admin menu
        add_action( 'admin_head', array( $this, 'admin_menu_icon_style' ) );
    }

    /**
     * Add the Admin Menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __( 'Jdac Logistics', 'jdac-logistics' ),
            __( 'Jdac Logistics', 'jdac-logistics' ),
            'manage_options',
            'jdac-logistics',
            array( $this, 'render_dashboard_page' ),
            'dashicons-truck',
            56
        );
    }

    /**
     * Register Plugin Settings
     */
    public function register_settings() {
        register_setting( 'jdac_logistics_options', 'jdac_api_key' );
        register_setting( 'jdac_logistics_options', 'jdac_auto_sync' );
    }

    /**
     * Handle status change to processing or completed
     */
    public function handle_status_change( $order_id, $old_status, $new_status, $order ) {
        if ( in_array( $new_status, array( 'processing', 'completed', 'cancelled' ) ) ) {
            $this->send_order_to_jdac( $order_id );
        }
    }

    /**
     * Set the custom icon style for the menu
     */
    public function admin_menu_icon_style() {
        $icon_url = plugins_url( 'favi.png', __FILE__ );
        ?>
        <style>
            #toplevel_page_jdac-logistics .wp-menu-image {
                background: url('<?php echo esc_url($icon_url); ?>') no-repeat center center !important;
                background-size: 20px !important;
            }
            #toplevel_page_jdac-logistics .wp-menu-image:before {
                display: none !important;
            }
        </style>
        <?php
    }

    /**
     * Render the Plugin Dashboard Page
     */
    public function render_dashboard_page() {
        $api_key = get_option( 'jdac_api_key' );
        $auto_sync = get_option( 'jdac_auto_sync' );
        ?>
        <div class="wrap jdac-dashboard">
            <h1><?php _e( 'Jdac Logistics Settings', 'jdac-logistics' ); ?></h1>
            <p><?php _e( 'Configure your connection to Jdac Logistics portal.', 'jdac-logistics' ); ?></p>

            <form method="post" action="options.php">
                <?php settings_fields( 'jdac_logistics_options' ); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><?php _e( 'API Key', 'jdac-logistics' ); ?></th>
                        <td>
                            <input type="password" name="jdac_api_key" value="<?php echo esc_attr( $api_key ); ?>" class="regular-text" />
                            <p class="description"><?php _e( 'Enter your API key from ship.jdaclogistics.com.', 'jdac-logistics' ); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php _e( 'Auto-Sync Orders', 'jdac-logistics' ); ?></th>
                        <td>
                            <input type="checkbox" name="jdac_auto_sync" value="1" <?php checked( 1, $auto_sync ); ?> />
                            <?php _e( 'Automatically send processing, completed, and cancelled orders to Jdac.', 'jdac-logistics' ); ?>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>

            <hr />

            <div class="jdac-portal-link" style="margin-top: 20px; padding: 20px; background: #fff; border-left: 4px solid #0073aa; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <h3><?php _e( 'Manage Portals', 'jdac-logistics' ); ?></h3>
                <p><?php _e( 'Access your Jdac Logistics dashboard to manage shipments, track orders, and more.', 'jdac-logistics' ); ?></p>
                <a href="https://ship.jdaclogistics.com/" target="_blank" class="button button-primary button-large"><?php _e( 'Go to Jdac Portal', 'jdac-logistics' ); ?></a>
            </div>
        </div>
        <?php
    }

    /**
     * Register REST API Endpoints
     */
    public function register_api_endpoints() {
        register_rest_route( 'jdac-logistics/v1', '/orders', array(
            'methods'             => 'GET',
            'callback'            => array( $this, 'get_recent_orders' ),
            'permission_callback' => array( $this, 'api_permission_check' ),
        ) );
    }

    /**
     * Check API Key for REST requests
     */
    public function api_permission_check( $request ) {
        $api_key = get_option( 'jdac_api_key' );
        $header_key = $request->get_header( 'X-JDAC-API-KEY' );
        return ( ! empty( $api_key ) && $header_key === $api_key );
    }

    /**
     * Get recent orders for REST API
     */
    public function get_recent_orders( $request ) {
        $args = array(
            'limit' => 50,
            'orderby' => 'date',
            'order' => 'DESC',
        );
        $orders = wc_get_orders( $args );
        $data = array();

        foreach ( $orders as $order ) {
            $data[] = array(
                'id'           => $order->get_id(),
                'status'       => $order->get_status(),
                'total'        => $order->get_total(),
                'currency'     => $order->get_currency(),
                'date_created' => $order->get_date_created()->date( 'Y-m-d H:i:s' ),
                'shipping'     => $order->get_address( 'shipping' ),
                'line_items'   => count( $order->get_items() ),
            );
        }

        return rest_ensure_response( $data );
    }

    /**
     * Send detailed order data to Jdac portal
     */
    public function send_order_to_jdac( $order_id ) {
        $auto_sync = get_option( 'jdac_auto_sync' );
        $api_key = get_option( 'jdac_api_key' );

        if ( ! $auto_sync || ! $api_key ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        // Prepare comprehensive order data
        $payload = array(
            'api_key'             => $api_key,
            'store_url'           => get_site_url(),
            'store_name'          => get_bloginfo( 'name' ),
            'id'                  => $order->get_id(),
            'order_number'        => $order->get_order_number(),
            'order_key'           => $order->get_order_key(),
            'status'              => $order->get_status(),
            'currency'            => $order->get_currency(),
            'date_created'        => $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i:s' ) : '',
            'date_modified'       => $order->get_date_modified() ? $order->get_date_modified()->date( 'Y-m-d H:i:s' ) : '',
            'date_paid'           => $order->get_date_paid() ? $order->get_date_paid()->date( 'Y-m-d H:i:s' ) : '',
            'date_completed'      => $order->get_date_completed() ? $order->get_date_completed()->date( 'Y-m-d H:i:s' ) : '',
            'customer_id'         => $order->get_customer_id(),
            'customer_ip_address' => $order->get_customer_ip_address(),
            'customer_user_agent' => $order->get_customer_user_agent(),
            'customer_note'       => $order->get_customer_note(),
            'payment_method'      => $order->get_payment_method(),
            'payment_method_title'=> $order->get_payment_method_title(),
            'transaction_id'      => $order->get_transaction_id(),
            'total'               => $order->get_total(),
            'subtotal'            => $order->get_subtotal(),
            'total_tax'           => $order->get_total_tax(),
            'total_discount'      => $order->get_total_discount(),
            'shipping_total'      => $order->get_shipping_total(),
            'shipping_tax'        => $order->get_shipping_tax(),
            'billing'             => $order->get_address( 'billing' ),
            'shipping'            => $order->get_address( 'shipping' ),
            'line_items'          => array(),
            'shipping_lines'      => array(),
            'fee_lines'           => array(),
            'coupon_lines'        => array(),
            'tax_lines'           => array(),
        );

        // Line Items
        foreach ( $order->get_items() as $item_id => $item ) {
            $product = $item->get_product();
            $item_data = array(
                'item_id'      => $item_id,
                'product_id'   => $item->get_product_id(),
                'variation_id' => $item->get_variation_id(),
                'sku'          => $product ? $product->get_sku() : '',
                'name'         => $item->get_name(),
                'quantity'     => $item->get_quantity(),
                'subtotal'     => $item->get_subtotal(),
                'total'        => $item->get_total(),
                'price'        => $product ? $product->get_price() : 0,
                'weight'       => $product ? $product->get_weight() : '',
                'dimensions'   => array(
                    'length' => $product ? $product->get_length() : '',
                    'width'  => $product ? $product->get_width() : '',
                    'height' => $product ? $product->get_height() : '',
                ),
                'L'            => $product ? $product->get_length() : '',
                'W'            => $product ? $product->get_width() : '',
                'H'            => $product ? $product->get_height() : '',
                'product_url'  => $product ? get_permalink( $product->get_id() ) : '',
                'image_url'    => $product ? wp_get_attachment_url( $product->get_image_id() ) : '',
                'categories'   => array(),
            );

            if ( $product ) {
                $categories = get_the_terms( $product->get_id(), 'product_cat' );
                if ( $categories && ! is_wp_error( $categories ) ) {
                    foreach ( $categories as $category ) {
                        $item_data['categories'][] = $category->name;
                    }
                }
            }
            $payload['line_items'][] = $item_data;
        }

        // Shipping Lines
        foreach ( $order->get_shipping_methods() as $item_id => $item ) {
            $payload['shipping_lines'][] = array(
                'id'           => $item_id,
                'method_title' => $item->get_method_title(),
                'method_id'    => $item->get_method_id(),
                'total'        => $item->get_total(),
            );
        }

        // Send to Jdac API
        error_log( 'Jdac Logistics: Attempting to sync order #' . $order_id );
        $response = wp_remote_post( 'https://ship.jdaclogistics.com/api/v1/orders', array(
            'method'      => 'POST',
            'timeout'     => 45,
            'headers'     => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ),
            'body'        => json_encode( $payload ),
        ) );

        if ( is_wp_error( $response ) ) {
            error_log( 'Jdac Logistics Sync Error: ' . $response->get_error_message() );
        } else {
            error_log( 'Jdac Logistics Sync Success for #' . $order_id );
        }
    }
}

// Initialize the plugin
new Jdac_Logistics_Plugin();

}
